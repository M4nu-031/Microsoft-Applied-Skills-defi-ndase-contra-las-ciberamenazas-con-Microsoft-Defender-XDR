# Applied Skills: Defend against cyberthreats with Microsoft Defender XDR

Manual paso a paso (en español) para completar al 100 % el laboratorio del Microsoft Applied Skill
[Defend against cyberthreats with Microsoft Defender XDR](https://learn.microsoft.com/credentials/applied-skills/defend-against-cyberthreats-with-microsoft-defender-xdr/).

## Contenido
- `docs/Manual_AppliedSkills_DefenderXDR.pdf`: manual completo (índice, 4 ejercicios, KQL listo para copiar, apéndice).
- `docs/Manual_AppliedSkills_DefenderXDR.md`: versión en Markdown.
- `docs/img/`: capturas de los ejercicios.

## KQL de la regla de detección (SuspiciousPowershell)
```kusto
DeviceProcessEvents
| where InitiatingProcessFileName =~ "powershell.exe"
| where FileName =~ "notepad.exe"
```

Basado en documentación oficial de Microsoft Learn. Material de apoyo; no es contenido oficial de Microsoft.
